//import Jama.Matrix;

public class Main {
	/*
	 * build your own if you like, this is just an example of how to start the viewer
	 * ...
	 */

	public static void main( String[] args) {
//		Matrix m = new Matrix(4, 4);
	}
}
